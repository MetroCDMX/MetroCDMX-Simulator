import csv
import os
import networkx as nx
def getMetro():
    """
    Funcion para obtener grafo del metro, en el que los pesos son distancias reales entre dos estaciones
    """
    # Crear un grafo vacio
    grafo = nx.Graph()

    # Leer coordsCDMX.csv
    # Usamos os.path.dirname(__file__) para asegurar que busca en la misma carpeta que este script
    coordsPath = os.path.join(os.path.dirname(__file__), "coordsCDMX.csv")
    
    with open(coordsPath, newline="", encoding="utf-8") as file:
        reader = csv.DictReader(file)
        coords = list(reader)

    # Leer conexiones.csv
    conexionesPath = os.path.join(os.path.dirname(__file__), "conexiones.csv")
    
    with open(conexionesPath, newline="", encoding="utf-8") as file:
        reader = csv.DictReader(file)
        conexiones = list(reader)

    # Crear nodos
    for fila in coords:
        grafo.add_node(
            fila['Nombre'],
            lat=float(fila['Latitud']),
            lon=float(fila['Longitud'])
        )

    # Crear aristas
    for fila in conexiones:
        grafo.add_edge(
            fila['Origen'],
            fila['Destino'],
            weight=float(fila['Peso'])
        )

    return grafo