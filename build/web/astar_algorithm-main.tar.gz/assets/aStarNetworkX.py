import networkx as nx
import math
from typing import Callable, Dict, List, Tuple

'''
MODULO A* CON NETWORKX
Corregido para coincidir con atributos 'lat' y 'lon' de metroCDMX.py
'''

# Variable global para almacenar el grafo
GRAFO_GLOBAL = None

# ---------------- FUNCIONES AUXILIARES ---------------- #

def haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Calcula la distancia Haversine (geodésica) en Kilómetros."""
    R = 6371.0  # Radio de la Tierra en km

    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    
    a = (math.sin(dlat / 2) ** 2 +
         math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) *
         math.sin(dlon / 2) ** 2)
    
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    
    return R * c

def getPath(cameFrom: Dict[str, str], current: str, start: str) -> List[str]:
    """Reconstruye el camino desde el nodo actual hasta el inicio."""
    path = [current]
    nextVertexInPath = current
    while nextVertexInPath != start:
        parent = cameFrom[nextVertexInPath]
        path.insert(0, parent)
        nextVertexInPath = parent
    return path

# ---------------- HEURÍSTICAS ---------------- #

def MSTHeuristic(graph: nx.Graph, start: str, goal: str, current: str, openSet: List[str], cameFrom: Dict[str, str]):
    currentPath = getPath(cameFrom, current, start)
    edges_to_remove = [(currentPath[i-1], currentPath[i]) for i in range(1, len(currentPath))]

    g = graph.copy() 
    g.remove_edges_from(edges_to_remove)
    
    if g.is_directed():
        g = g.to_undirected()

    mst_edges = nx.minimum_spanning_edges(g, weight='weight', data=True)
    return sum(edge_data['weight'] for u, v, edge_data in mst_edges)

def djikstraHeuristic(graph: nx.Graph, start: str, goal: str, current: str, openSet: List[str], cameFrom: Dict[str, str]):
    currentPath = getPath(cameFrom, current, start)
    edges_to_remove = [(currentPath[i-1], currentPath[i]) for i in range(1, len(currentPath))]

    g = graph.copy()
    g.remove_edges_from(edges_to_remove)

    try:
        return nx.shortest_path_length(g, source=current, target=goal, weight='weight')
    except nx.NetworkXNoPath:
        return float('inf')

def euclideanDistanceHeuristic(graph: nx.Graph, start: str, goal: str, current: str, openSet: List[str], cameFrom: Dict[str, str]):
    """
    Implementa la distancia geodésica.
    Usa 'lat' y 'lon' para coincidir con tu metroCDMX.py
    """
    curr_data = graph.nodes[current]
    goal_data = graph.nodes[goal]
    
    # AQUÍ ESTABA EL ERROR: Cambiado de 'long' a 'lon'
    return haversine_distance(curr_data["lat"], curr_data["lon"], 
                              goal_data["lat"], goal_data["lon"])

# ---------------- ALGORITMO PRINCIPAL ---------------- #

def AStar(graph: nx.Graph, 
          heuristic: Callable, 
          start_vertex: str, 
          end_vertex: str) -> Tuple[List[str], List[str]]:

    if start_vertex == end_vertex: 
        return [start_vertex], [start_vertex]

    intermediatePath: List[str] = []
    start = start_vertex
    goal = end_vertex

    openSet: List[str] = [start]
    cameFrom: Dict[str, str] = dict()

    gScore: Dict[str, float] = {node: float('inf') for node in graph.nodes} 
    gScore[start] = 0

    fScore: Dict[str, float] = {node: float('inf') for node in graph.nodes}
    
    try:
        h_val = heuristic(graph, start, goal, start, openSet, cameFrom)
    except Exception:
        h_val = 0
    fScore[start] = h_val

    while len(openSet) != 0:
        current = min(openSet, key=fScore.get)
        intermediatePath.append(current)

        if current == goal:      
            finalRoute = getPath(cameFrom, current, start)
            return intermediatePath, finalRoute

        openSet.remove(current)

        for neighbor in graph.neighbors(current):
            edge_data = graph[current][neighbor]
            weight = edge_data.get('weight', 1) 

            new_gScore = gScore[current] + weight
            
            if new_gScore < gScore[neighbor]:
                cameFrom[neighbor] = current
                gScore[neighbor] = new_gScore
                fScore[neighbor] = new_gScore + heuristic(graph, start, goal, neighbor, openSet, cameFrom)

                if neighbor not in openSet:
                    openSet.append(neighbor)
    
    return [], []

# ---------------- ADAPTADORES UI ---------------- #

def inicializar_algoritmo(graph: nx.Graph):
    global GRAFO_GLOBAL
    GRAFO_GLOBAL = graph
    print(f"Grafo inicializado correctamente (Nodos: {len(graph.nodes)})")

def caminoOptimo(start_vertex: str, end_vertex: str) -> List[str]:
    if GRAFO_GLOBAL is None:
        print("Error: Grafo no inicializado.")
        return []

    # Llamamos al algoritmo con la heurística correcta
    intermediate, final = AStar(GRAFO_GLOBAL, euclideanDistanceHeuristic, start_vertex, end_vertex)
    return final